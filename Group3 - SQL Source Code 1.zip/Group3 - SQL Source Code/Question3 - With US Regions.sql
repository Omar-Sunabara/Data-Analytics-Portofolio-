SELECT [Name], [SalesYTD]
FROM [AdventureWorks2019].[Sales].[SalesTerritory]
