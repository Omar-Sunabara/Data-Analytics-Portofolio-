SELECT [JobTitle], [SickLeaveHours]
FROM [AdventureWorks2019].[HumanResources].[Employee]
